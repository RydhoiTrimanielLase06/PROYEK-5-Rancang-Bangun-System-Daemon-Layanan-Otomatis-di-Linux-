#!/bin/bash

# Konfigurasi Direktori
SOURCE_DIR="/var/log/myapp"
BACKUP_DIR="/var/backups/log_archive"
LOG_FILE="/var/log/log_archiver.log"
RETENTION_DAYS=7

# Pastikan direktori backup ada
mkdir -p "$BACKUP_DIR"

# Fungsi pencatatan log
log_message() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

log_message "Daemon dimulai: Memindai file log yang lebih tua dari $RETENTION_DAYS hari."

# Cari file log lama, kompres, lalu hapus aslinya
find "$SOURCE_DIR" -type f -name "*.log" -mtime +$RETENTION_DAYS | while read file; do
    filename=$(basename "$file")
    archive_name="${filename}_$(date +%F).tar.gz"

    # Proses Kompresi
    if tar -czf "$BACKUP_DIR/$archive_name" -C "$SOURCE_DIR" "$filename"; then
        log_message "BERHASIL: Mengarsipkan $filename ke $BACKUP_DIR/$archive_name"

        # Hapus file asli setelah arsip sukses
        rm "$file"
        log_message "INFO: File asli $file telah dihapus."
    else
        log_message "ERROR: Gagal mengarsipkan $file"
    fi
done

log_message "Daemon selesai: Tugas archiving tuntas."
