# Project 5: Rancang Bangun System Daemon (Layanan Otomatis di Linux)
Repository ini berisi implementasi Log Archiver Daemon menggunakan Bash dan Systemd.
